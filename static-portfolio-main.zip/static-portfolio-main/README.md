# static-portfolio
my first static portfolio using HTML and CSS learnt from scratch. 
